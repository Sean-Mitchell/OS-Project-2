//Method Headers
void *reindeerThread(void *args);
void *elfThread(void *args);
void *santaThread(void *args);
void helpElves();
void deliverPresents();
void santaHelper();
void reindeerHelper();
void elvesHelper();